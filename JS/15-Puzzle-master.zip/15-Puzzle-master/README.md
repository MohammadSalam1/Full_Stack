# 15 Puzzle

JavaScript game: 15 Puzzle - [click here](https://arnisritins.github.io/15-Puzzle/) to play it online!
